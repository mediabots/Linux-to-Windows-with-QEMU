$i = 432000
do {
   Write-Host $i
   sleep 1
   $i--   
} while ($i -gt 0)